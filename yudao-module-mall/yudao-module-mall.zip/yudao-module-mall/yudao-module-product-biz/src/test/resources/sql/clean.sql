DELETE FROM "product_sku";

DELETE FROM "product_spu";