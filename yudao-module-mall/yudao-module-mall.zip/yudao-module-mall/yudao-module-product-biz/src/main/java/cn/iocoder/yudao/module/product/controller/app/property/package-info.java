/**
 * 占位符，无时间作用，避免 package 缩进
 */
package cn.iocoder.yudao.module.product.controller.app.property;
