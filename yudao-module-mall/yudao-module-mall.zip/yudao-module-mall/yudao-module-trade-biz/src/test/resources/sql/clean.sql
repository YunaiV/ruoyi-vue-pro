DELETE FROM trade_order;
DELETE FROM trade_order_item;
DELETE FROM trade_after_sale;
DELETE FROM trade_after_sale_log;
