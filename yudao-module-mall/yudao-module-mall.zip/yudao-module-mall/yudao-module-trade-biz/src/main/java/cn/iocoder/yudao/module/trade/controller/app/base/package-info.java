/**
 * 基础包，放一些通用的 VO 类
 */
package cn.iocoder.yudao.module.trade.controller.app.base;
