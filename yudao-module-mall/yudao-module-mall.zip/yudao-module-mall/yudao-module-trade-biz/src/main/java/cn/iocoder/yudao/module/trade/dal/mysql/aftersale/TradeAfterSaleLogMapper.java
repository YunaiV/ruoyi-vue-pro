package cn.iocoder.yudao.module.trade.dal.mysql.aftersale;

import cn.iocoder.yudao.framework.mybatis.core.mapper.BaseMapperX;
import cn.iocoder.yudao.module.trade.dal.dataobject.aftersale.TradeAfterSaleLogDO;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TradeAfterSaleLogMapper extends BaseMapperX<TradeAfterSaleLogDO> {
}
