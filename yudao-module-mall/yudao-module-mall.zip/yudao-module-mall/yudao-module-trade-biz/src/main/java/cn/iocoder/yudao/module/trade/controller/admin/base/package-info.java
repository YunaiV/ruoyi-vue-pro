/**
 * 放置该模块通用的 VO 类
 */
package cn.iocoder.yudao.module.trade.controller.admin.base;
