DELETE FROM "market_activity";
DELETE FROM "promotion_coupon_template";
DELETE FROM "promotion_coupon";
DELETE FROM "promotion_reward_activity";
DELETE FROM "promotion_discount_activity";
DELETE FROM "promotion_discount_product";
